PROMS Server
============

PROMS Server is a web server and database application consisting of a Python Flask RESTful API that enforces data policy according to the PROMS methodologies outlined at https://wiki.csiro.au/display/PROMS.

PROMS Server may be installed as per instructions in the installation/ subfolder.


Features
--------
Please see the CAHGELOG.md file for version notes.


Support
-------
More information is available on the project webpage: https://wiki.csiro.au/display/PROMS.
